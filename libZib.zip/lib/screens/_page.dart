// // 📁 lib/screens/walking_page.dart

// import 'package:flutter/material.dart';
// import 'HomePage.dart';
// import '../services/servis_walk.dart';

// class WalkingPage extends StatelessWidget {
//   const WalkingPage({super.key});

//   @override
//   Widget build(BuildContext context) {

//     return Scaffold(
//       appBar: AppBar(title: const Text("Выгул собак")),

//       body: ListView(
//         padding: const EdgeInsets.all(16),

//         children: const [

//           ServiceBigCard(
//             title: "Прогулка 30 мин",
//             price: "1500 ₸",
//             description: "Короткая прогулка рядом с домом",
//           ),

//           SizedBox(height: 16),

//           ServiceBigCard(
//             title: "Прогулка 1 час",
//             price: "2500 ₸",
//             description: "Активная прогулка с играми",
//           ),

//         ],
//       ),
//     );
//   }
// }