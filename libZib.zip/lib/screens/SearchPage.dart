import '../models/prduct_model.dart';
import 'ItemInfo.dart';
import 'package:flutter/material.dart';
import 'productCardlogic.dart';

// class SearchPage extends StatefulWidget{
//   const SearchPage ({super.key});

//    @override
//   State<SearchPage> createState() => _SearchPage();
// }


// class _SearchPage extends State<SearchPage> {

//   @override
// void initState() {
//   super.initState();
// }
// String query = '';
// @override
// void dispose() {
//   super.dispose();
// }


//  @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: EdgeInsets.symmetric(horizontal: 15),
//       child: Column(
//         children: [
//           SearchAndFilter(
//             onChanged: (value) {
//               setState(() {
//                 query = value;
//               });
//             },
//           ),

//           // 👇 ВАЖНО
//           Expanded(
//             child: ResultsList(
//               query: query,
//               products: products,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// class SearchAndFilter extends StatelessWidget {
//   final Function(String) onChanged;

//   const SearchAndFilter({super.key, required this.onChanged});

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.all(16),
//       child: TextField(
//         onChanged: onChanged,
//         decoration: InputDecoration(
//           hintText: 'search animals...',
//           prefixIcon: Icon(Icons.search),
//         ),
//       ),
//     );
//   }
// }


// class ResultsList extends StatelessWidget {
//   final String query;
//   final List<Animal> products;

//   const ResultsList({
//     super.key,
//     required this.query,
//     required this.products,
//   });

//   @override
//   Widget build(BuildContext context) {
//     final filtered = products.where((product) {
//       return product.description
//         .toLowerCase()
//         .contains(query.toLowerCase());
//     }).toList();

//     if (filtered.isEmpty) {
//       return const Text("Ничего не найдено");
//     }

//     return GridView.builder(
//       physics: const AlwaysScrollableScrollPhysics(), 
//       gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//         crossAxisCount: 2,
//         crossAxisSpacing: 10,
//         mainAxisSpacing: 10,
//         childAspectRatio: 0.65,
//       ),
//       itemCount: filtered.length,
//       itemBuilder: (context, index) {
//         final product = filtered[index];

//         return GestureDetector(
//           onTap: () {
//             Navigator.push(
//               context,
//               MaterialPageRoute(
//                 builder: (context) => ItemInfo(product: product),
//               ),
//             );
//           },
//           child: ProductCard(product: product),
//         );
//       },
//     );
//   }
// }

