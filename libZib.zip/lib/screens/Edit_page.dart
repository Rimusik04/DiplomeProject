import 'package:flutter/material.dart';
import '../models/prduct_model.dart';

// class EditProductPage extends StatefulWidget {
//   final Animal product;
//   final int index;

//   const EditProductPage({
//     super.key,
//     required this.product,
//     required this.index,
//   });

//   @override
//   State<EditProductPage> createState() => _EditProductPageState();
// }

// class _EditProductPageState extends State<EditProductPage> {
//   late TextEditingController nameController;
//   late TextEditingController priceController;
//   late TextEditingController descController;

//   @override
//   void initState() {
//     super.initState();

//     nameController = TextEditingController(text: widget.product.name);
//     priceController =
//         TextEditingController(text: widget.product.price.toString());
//     descController =
//         TextEditingController(text: widget.product.description);
//   }

//   void saveChanges() {
//     products[widget.index] = Animal(
//       id: widget.product.id, // 🔥 НЕ МЕНЯЕМ ID
//       images: widget.product.images,
//       name: nameController.text,
//       price: int.parse(priceController.text),
//       decount: widget.product.decount,
//       description: descController.text,
//       age: widget.product.age,
//       Status: widget.product.Status,
//     );

//     Navigator.pop(context);
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Edit Product")),
//       body: Padding(
//         padding: const EdgeInsets.all(16),
//         child: Column(
//           children: [
//             TextField(controller: nameController),
//             TextField(controller: priceController),
//             TextField(controller: descController),

//             const SizedBox(height: 20),

//             ElevatedButton(
//               onPressed: saveChanges,
//               child: const Text("Save"),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }