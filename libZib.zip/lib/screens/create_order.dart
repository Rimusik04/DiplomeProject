// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';

// class CreateOrderPage extends StatefulWidget {
//   const CreateOrderPage({super.key});

//   @override
//   State<CreateOrderPage> createState() => _CreateOrderPageState();
// }


// class _CreateOrderPageState extends State<CreateOrderPage> {

//   final addressController = TextEditingController();
//   final dateController = TextEditingController();

//   DateTime? selectedDate;

//   // 📅 выбор даты
//   Future pickDate() async {

//     final picked = await showDatePicker(
//       context: context,
//       initialDate: DateTime.now(),
//       firstDate: DateTime.now(),
//       lastDate: DateTime(2030),
//     );

//     if (picked != null) {
//       setState(() {
//         selectedDate = picked;
//         dateController.text =
//             DateFormat('dd.MM.yyyy').format(picked);
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {

//     return Scaffold(
//       backgroundColor: Colors.grey[100],

//       appBar: AppBar(
//         title: const Text("Создать заказ"),
//         centerTitle: true,
//         elevation: 0,
//       ),

//       body: Column(
//         children: [

//           Expanded(
//             child: ListView(
//               padding: const EdgeInsets.all(16),
//               children: [

//                 // 📍 Адрес
//                 _inputCard(
//                   icon: Icons.location_on,
//                   title: "Адрес",
//                   child: TextField(
//                     controller: addressController,
//                     decoration: const InputDecoration(
//                       hintText: "Введите адрес",
//                       border: InputBorder.none,
//                     ),
//                   ),
//                 ),

//                 const SizedBox(height: 16),

//                 // 📅 Дата
//                 _inputCard(
//                   icon: Icons.calendar_today,
//                   title: "Дата",
//                   child: TextField(
//                     controller: dateController,
//                     readOnly: true,
//                     onTap: pickDate,
//                     decoration: const InputDecoration(
//                       hintText: "Выберите дату",
//                       border: InputBorder.none,
//                     ),
//                   ),
//                 ),

//                 const SizedBox(height: 20),

//                 // ℹ️ Инфо
//                 Container(
//                   padding: const EdgeInsets.all(14),
//                   decoration: BoxDecoration(
//                     color: Colors.blue.withOpacity(0.1),
//                     borderRadius: BorderRadius.circular(15),
//                   ),
//                   child: const Row(
//                     children: [
//                       Icon(Icons.info_outline, color: Colors.blue),
//                       SizedBox(width: 10),
//                       Expanded(
//                         child: Text(
//                           "Исполнитель свяжется с вами после оформления заказа",
//                         ),
//                       )
//                     ],
//                   ),
//                 ),

//               ],
//             ),
//           ),

//           // 🔘 Кнопка
//           Container(
//             padding: const EdgeInsets.all(16),
//             color: Colors.white,

//             child: SizedBox(
//               width: double.infinity,
//               child: ElevatedButton(
//                 style: ElevatedButton.styleFrom(
//                   padding: const EdgeInsets.symmetric(vertical: 16),
//                 ),

//                 onPressed: () {

//                   if (addressController.text.isEmpty ||
//                       dateController.text.isEmpty) {

//                     ScaffoldMessenger.of(context).showSnackBar(
//                       const SnackBar(
//                         content: Text("Заполни все поля"),
//                       ),
//                     );
//                     return;
//                   }

//                   ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(
//                       content: Text("Заказ создан 🎉"),
//                     ),
//                   );

//                   Navigator.pop(context);
//                 },

//                 child: const Text("Подтвердить"),
//               ),
//             ),
//           )

//         ],
//       ),
//     );
//   }

//   // 🔧 карточка input
//   Widget _inputCard({
//     required IconData icon,
//     required String title,
//     required Widget child,
//   }) {
//     return Container(
//       padding: const EdgeInsets.all(14),

//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(15),
//       ),

//       child: Row(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [

//           Icon(icon),

//           const SizedBox(width: 10),

//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [

//                 Text(
//                   title,
//                   style: const TextStyle(color: Colors.grey),
//                 ),

//                 child,

//               ],
//             ),
//           )

//         ],
//       ),
//     );
//   }
// }