import 'package:cloud_firestore/cloud_firestore.dart';

class OrderModel {
  final String id;
  final String userId;
  final String serviceType; // walking, boarding, grooming, vet, training, taxi
  final String specificService; // конкретная услуга
  final String petName;
  final String location;
  final String date;
  final String time;
  final int price;
  final String status; // active, in_progress, completed, cancelled
  final String notes;

  // 🐶 питомец
  final String petAge;
  final String petGender;
  final String petColor;
  final String? petImageUrl;

  // ⭐ и тип услуги
  final double minRating;
  final String serviceCategory;

  // 📍 гео
  final double? lat;
  final double? lng;
  
  // 🕐 Специфичные поля для разных услуг
  final int? walkingHours;      // для выгула (1-5 часов)
  final int? boardingDays;       // для передержки (1-7 дней)
  final String? groomingService; // для груминга
  final String? vetService;      // для ветпомощи
  final String? trainingType;    // для дрессировки
  final String? taxiType;        // для зоотакси
  
  // 📞 Контактные данные
  final String phoneNumber;
  
  // 📅 Время создания
  final DateTime? createdAt;

  OrderModel({
    required this.id,
    required this.userId,
    required this.serviceType,
    required this.specificService,
    required this.petName,
    required this.location,
    required this.date,
    required this.time,
    required this.price,
    required this.status,
    required this.notes,
    required this.petAge,
    required this.petGender,
    required this.petColor,
    this.petImageUrl,
    required this.minRating,
    required this.serviceCategory,
    this.lat,
    this.lng,
    this.walkingHours,
    this.boardingDays,
    this.groomingService,
    this.vetService,
    this.trainingType,
    this.taxiType,
    required this.phoneNumber,
    this.createdAt,
  });

  // 🔄 из Firestore
  factory OrderModel.fromMap(String id, Map<String, dynamic> data) {
    return OrderModel(
      id: id,
      userId: data['userId'] ?? '',
      serviceType: data['serviceType'] ?? '',
      specificService: data['specificService'] ?? '',
      petName: data['petName'] ?? '',
      location: data['location'] ?? '',
      date: data['date'] ?? '',
      time: data['time'] ?? '',
      price: (data['price'] ?? 0).toInt(),
      status: data['status'] ?? 'active',
      notes: data['notes'] ?? '',
      
      // 🐶
      petAge: data['petAge'] ?? '',
      petGender: data['petGender'] ?? '',
      petColor: data['petColor'] ?? '',
      petImageUrl: data['petImageUrl'],
      
      // ⭐
      minRating: (data['minRating'] ?? 0).toDouble(),
      serviceCategory: data['serviceCategory'] ?? '',
      
      // 📍
      lat: data['lat'] != null ? (data['lat']).toDouble() : null,
      lng: data['lng'] != null ? (data['lng']).toDouble() : null,
      
      // 🕐 Специфичные поля
      walkingHours: data['walkingHours'],
      boardingDays: data['boardingDays'],
      groomingService: data['groomingService'],
      vetService: data['vetService'],
      trainingType: data['trainingType'],
      taxiType: data['taxiType'],
      
      // 📞
      phoneNumber: data['phoneNumber'] ?? '',
      
      // 📅
      createdAt: data['createdAt'] != null 
          ? (data['createdAt'] as Timestamp).toDate() 
          : null,
    );
  }

  // 🔥 в Firestore
  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'serviceType': serviceType,
      'specificService': specificService,
      'petName': petName,
      'location': location,
      'date': date,
      'time': time,
      'price': price,
      'status': status,
      'notes': notes,
      
      // 🐶
      'petAge': petAge,
      'petGender': petGender,
      'petColor': petColor,
      'petImageUrl': petImageUrl,
      
      // ⭐
      'minRating': minRating,
      'serviceCategory': serviceCategory,
      
      // 📍
      'lat': lat,
      'lng': lng,
      
      // 🕐 Специфичные поля
      'walkingHours': walkingHours,
      'boardingDays': boardingDays,
      'groomingService': groomingService,
      'vetService': vetService,
      'trainingType': trainingType,
      'taxiType': taxiType,
      
      // 📞
      'phoneNumber': phoneNumber,
      
      // 📅
      'createdAt': createdAt != null 
          ? Timestamp.fromDate(createdAt!) 
          : FieldValue.serverTimestamp(),
    };
  }
  
  // 🆔 Получить детали услуги для отображения
  String getServiceDetails() {
    switch (specificService) {
      case "walking":
        return "Выгул: $walkingHours ч";
      case "boarding":
        return "Передержка: $boardingDays дн";
      case "grooming":
        return "Груминг: $groomingService";
      case "vet":
        return "Ветпомощь: $vetService";
      case "training":
        return "Дрессировка: $trainingType";
      case "taxi":
        return "Зоотакси: $taxiType";
      default:
        return "";
    }
  }
  
  // 💰 Получить базовую цену для отображения
  String getFormattedPrice() {
    return "$price ₸";
  }
  
  // ✅ Проверить активен ли заказ
  bool isActive() {
    return status == "active" || status == "in_progress";
  }
  
  // // 🎨 Получить цвет статуса
  // Color getStatusColor() {
  //   switch (status) {
  //     case "completed":
  //       return Colors.green;
  //     case "cancelled":
  //       return Colors.red;
  //     case "in_progress":
  //       return Colors.orange;
  //     default:
  //       return Colors.blue;
  //   }
  // }
  
  // 📝 Получить текст статуса
  String getStatusText() {
    switch (status) {
      case "completed":
        return "Выполнен";
      case "cancelled":
        return "Отменен";
      case "in_progress":
        return "В процессе";
      default:
        return "Активен";
    }
  }
  
  // 🎨 Получить иконку статуса
  // IconData getStatusIcon() {
  //   switch (status) {
  //     case "completed":
  //       return Icons.check_circle;
  //     case "cancelled":
  //       return Icons.cancel;
  //     case "in_progress":
  //       return Icons.play_circle;
  //     default:
  //       return Icons.pending;
  //   }
  // }
}