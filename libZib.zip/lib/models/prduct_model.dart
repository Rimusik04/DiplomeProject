class Animal {
  final String id;
  final String images;
  final String name;
  final int price;
  final int decount;
  final int age;
  final String description;
  final String Status;

  Animal({
    required this.id,
    required this.images,
    required this.name,
    required this.price,
    required this.decount,
    required this.description,
    required this.age,
    required this.Status,
  });
  
 }
// final List<Animal> products = [
//   Animal(
//     id: "1",
//     name: "Bella",
//     decount: 10000,
//     images: "assets/image/dog.jpg",
//     price: 9999,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "2",
//     name: "Milo",
//     decount: 4000,
//     images: "assets/image/dog1.jpg",
//     price: 1900,
//     description: "Playful kitten, very affectionate.",
//     age: 2,
//     Status: "Sells"
//   ),
//   Animal(
//     id: "3",
//     name: "Pol",
//     decount: 10000,
//     images: "assets/image/dog2.jpg",
//     price: 9999,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "4",
//     name: "Moko",
//     decount: 4000,
//     images: "assets/image/dog3.jpg",
//     price: 1900,
//     description: "Playful kitten, very affectionate.",
//     age: 2,
//     Status: "Sells"
//   ),
//   Animal(
//     id: "5",
//     name: "Reks",
//     decount: 10000,
//     images: "assets/image/cat.jpg",
//     price: 9999,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "6",
//     name: "Look",
//     decount: 4000,
//     images: "assets/image/cat1.jpg",
//     price: 1900,
//     description: "Playful kitten, very affectionate.",
//     age: 2,
//     Status: "Sells"
//   ),
//   Animal(
//     id: "7",
//     name: "Tom",
//     decount: 10000,
//     images: "assets/image/cat2.jpg",
//     price: 9999,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "8",
//     name: "Noal",
//     decount: 4000,
//     images: "assets/image/cat3.jpg",
//     price: 1900,
//     description: "Playful kitten, very affectionate.",
//     age: 2,
//     Status: "Sells"
//   ),
//   Animal(
//     id: "9",
//     name: "Mool",
//     decount: 10000,
//     images: "assets/image/cat4.jpg",
//     price: 9999,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "10",
//     name: "Shown",
//     decount: 4000,
//     images: "assets/image/pet1.jpg",
//     price: 1900,
//     description: "Playful kitten, very affectionate.",
//     age: 2,
//     Status: "Sells"
//   ),
//   Animal(
//     id: "11",
//     name: "Grey",
//     decount: 10000,
//     images: "assets/image/pet2.jpg",
//     price: 9999,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "12",
//     name: "Snow",
//     decount: 4000,
//     images: "assets/image/pet1.jpg",
//     price: 1900,
//     description: "Playful kitten, very affectionate.",
//     age: 2,
//     Status: "Sells"
//   ),
//   Animal(
//     id: "13",
//     name: "Moko",
//     decount: 10000,
//     images: "assets/image/pet3.jpg",
//     price: 9999,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "14",
//     name: "Coat",
//     decount: 4000,
//     images: "assets/image/pet4.jpg",
//     price: 1900,
//     description: "Playful kitten, very affectionate.",
//     age: 2,
//     Status: "Sells"
//   ),
//   Animal(
//     id: "15",
//     name: "Blu",
//     decount: 10000,
//     images: "assets/image/pet5.jpg",
//     price: 6723,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "16",
//     name: "Viks",
//     decount: 95495,
//     images: "assets/image/pet1.jpg",
//     price: 2939,
//     description: "Playful kitten, very affectionate.",
//     age: 2,
//     Status: "Sells"
//   ),
//   Animal(
//     id: "17",
//     name: "Showl",
//     decount: 10000,
//     images: "assets/image/pet7.jpg",
//     price: 2355,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "18",
//     name: "Net",
//     decount: 456546,
//     images: "assets/image/pet8.jpg",
//     price: 1900,
//     description: "Playful kitten, very affectionate.",
//     age: 2,
//     Status: "Sells"
//   ),
//   Animal(
//     id: "19",
//     name: "Soul",
//     decount: 47445,
//     images: "assets/image/pet9.jpg",
//     price: 9999,
//     age: 3,
//     description: "Friendly golden retriever, loves kids.",
//     Status: "Sells"
//   ),
//   Animal(
//     id: "20",
//     name: "Baby",
//     decount: 3486,
//     images: "assets/image/pet10.jpg",
//     price: 299,
//     description: "Playful kitten, very Cute and Very Danger when he Stand up.",
//     age: 2,
//     Status: "Want to Buy"
//   ),
// ];