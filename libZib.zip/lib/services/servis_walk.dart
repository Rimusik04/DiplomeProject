// import 'package:flutter/material.dart';
// import '../screens/worker_page.dart';

// class ServiceBigCard extends StatelessWidget {

//   final String title;
//   final String price;
//   final String description;

//   const ServiceBigCard({
//     super.key,
//     required this.title,
//     required this.price,
//     required this.description,
//   });

//   @override
//   Widget build(BuildContext context) {

//     return GestureDetector(
//       onTap: () {
//         Navigator.push(
//           context,
//           MaterialPageRoute(builder: (_) => const WorkersPage()),
//         );
//       },

//       child: Container(
//         padding: const EdgeInsets.all(16),

//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(18),
//         ),

//         child: Row(
//           children: [

//             Container(
//               padding: const EdgeInsets.all(12),
//               decoration: BoxDecoration(
//                 color: Colors.orange.withOpacity(0.2),
//                 borderRadius: BorderRadius.circular(12),
//               ),
//               child: const Icon(Icons.pets),
//             ),

//             const SizedBox(width: 12),

//             Expanded(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [

//                   Text(title,
//                       style: const TextStyle(
//                           fontWeight: FontWeight.bold,
//                           fontSize: 16)),

//                   const SizedBox(height: 4),

//                   Text(description,
//                       style: const TextStyle(color: Colors.grey)),

//                 ],
//               ),
//             ),

//             Text(price,
//                 style: const TextStyle(
//                     fontWeight: FontWeight.bold,
//                     color: Colors.green)),

//           ],
//         ),
//       ),
//     );
//   }
// }