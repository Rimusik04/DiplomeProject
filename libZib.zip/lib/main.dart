import 'package:flutter/material.dart';
import 'login.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'firebase_options.dart'; // 👈 ДОБАВЬ ЭТОТ ИМПОРТ

import 'start.dart';
import 'screens/main_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // ✅ ПРАВИЛЬНАЯ инициализация Firebase
  await Firebase.initializeApp(
    // options: DefaultFirebaseOptions.currentPlatform,
  );
  
  final prefs = await SharedPreferences.getInstance();
  
  // hasSeenWelcome = true - если уже видел приветствие
  // hasSeenWelcome = false - если ещё не видел (первый запуск)
  final hasSeenWelcome = prefs.getBool('hasSeenWelcome') ?? false; // 👈 ИЗМЕНИЛ НА false

  runApp(MyApp(hasSeenWelcome: hasSeenWelcome));
}

class MyApp extends StatelessWidget {
  final bool hasSeenWelcome;
  const MyApp({super.key, required this.hasSeenWelcome});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color.fromARGB(158, 114, 159, 196),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
        ),
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      debugShowCheckedModeBanner: false,
      
      // 👇 ЛОГИКА НАВИГАЦИИ
      home: (FirebaseAuth.instance.currentUser == null)
          ? (hasSeenWelcome 
              ? const Login_Page()      // если уже видел приветствие → логин
              : const start_page())     // если первый раз → приветствие
          : const MainPage(),            // если залогинен → главная
    );
  }
}